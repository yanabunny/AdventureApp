//
//  ViewController.swift
//  BachelorGame
//
//  Created by Teriyana Cohens on 5/6/19.
//  Copyright © 2019 Teriyana Cohens. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func startButton(_ sender: Any) {
        performSegue(withIdentifier: "Transition", sender: self)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

