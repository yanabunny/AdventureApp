//
//  QuestionsBank.swift
//  BachelorGame
//
//  Created by Teriyana Cohens on 5/6/19.
//  Copyright © 2019 Teriyana Cohens. All rights reserved.
//

import Foundation
class QuestionBank{
    var list = [Question]()
        init(){
            //Question 0(Start Screen)
            list.append(Question(questionText: "Ready to Begin this Journey?", choiceA: "Yes", choiceB: "No", nextQuestionA:1, nextQuestionB: 1, rosePage: "No", rose1: "Yes", rose2:"Yes"))
            //Question 1(1.1)
            list.append(Question(questionText: "Choose a pickup line", choiceA: "Are you from Tennessee? Cause you’re the only ten I see.", choiceB: "I may not be the boy who lived, but I can still be your chosen one.", nextQuestionA:2, nextQuestionB: 3, rosePage: "No", rose1: "Yes", rose2:"Yes"))
            //Question 2(2.1)
            list.append(Question(questionText: "In the house, everyone’s mingling; he is talking to somebody else, do you want to go steal his attention?", choiceA: "Yes", choiceB: "No", nextQuestionA:4, nextQuestionB: 5, rosePage: "Yes", rose1: "Yes", rose2: "No"))
            //(Question 3(1.2)
            list.append(Question(questionText: "You’re talking to the bachelor and Hannah comes up and asks if they can interrupt you.", choiceA: "Yes", choiceB: "No", nextQuestionA: 4,nextQuestionB: 4,rosePage: "Yes", rose1: "Yes", rose2: "Yes" ))
            //Question 4
            list.append(Question(questionText: "Welcome to the Rose Ceremony! Chad is still intrigued. Do you except this Rose?", choiceA: "Yes", choiceB: "No", nextQuestionA:6, nextQuestionB:6, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 5
            list.append(Question(questionText: "Chad is no longer interested in continuing the journey with you", choiceA: "Restart", choiceB: "Exit", nextQuestionA:0, nextQuestionB:0, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 6
            list.append(Question(questionText: "You’ve been selected for a one-on-one!!! California helicopter date! Chad wants to know What do you like to do for fun?", choiceA: "I like to go out for drinks with my friends.", choiceB: "I like to volunteer at the homeless shelter.", nextQuestionA:7, nextQuestionB:7, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 7
            list.append(Question(questionText: "You had an amazing day with Chad. Now you're at dinner. Chad wants to know what would you say influenced how you got here today?", choiceA: "My Dead dog", choiceB: "My Parents Divorced", nextQuestionA:8, nextQuestionB:8, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 8
            list.append(Question(questionText: "Congrats! You got your one-on-one rose, do you accept?", choiceA: "Yes", choiceB: "No", nextQuestionA:9, nextQuestionB:9, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 9
            list.append(Question(questionText: "You were chosen to go on a Group Date!There are 10 people on the group date, including the girl you’re feuding with,Hannah G. Rollerskating Date! You’re skating hand in hand with the Bachelor! Hannah G. pushes you! You fall flat on your face How do you react?", choiceA: "Fight her", choiceB: "Laugh it off, blame it on your clumsiness", nextQuestionA:10, nextQuestionB:11, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 10
            list.append(Question(questionText: " Welcome to the cocktail Party! Do you want to apologize to the bachelor for causing a scene at the rollerskating rink?", choiceA: "Yes", choiceB: "No", nextQuestionA:12, nextQuestionB:13, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 11
            list.append(Question(questionText: "You’re talking with the bachelor, he is very smitten with how cute you were when you laughed about tripping. Do you want to tell the Bachelor that it was actually Hannah G. that pushed you?", choiceA: "Yes", choiceB: "No", nextQuestionA:13, nextQuestionB:12, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 12
            list.append(Question(questionText: "Congrats! Chad is smitten with you. He is offereing you the Group Date Rose! Do you accept this rose?", choiceA: "Yes", choiceB: "No", nextQuestionA:16, nextQuestionB:0, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 13
            list.append(Question(questionText: "You and Hannah have been chosen for a 2 on 1 date on an island. Only one of you will leave the island with your man.Choose Wisely: To save yourself are you going to tell the bachelor about Hannah’s evil ways or tell him you love him.", choiceA: "Hannah’s Evil Ways", choiceB: "You love him", nextQuestionA:14, nextQuestionB:15, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 14
            list.append(Question(questionText: "Chad was not happy with your snitch ways so he sent you home and are left on the island by yourself. Good Luck!", choiceA: "Restart", choiceB: "Exit", nextQuestionA:0, nextQuestionB:0, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 15
            list.append(Question(questionText: "Congrats! Chad is smitten with you. He is offereing you the 2 on 1 Rose! He is falling in love with you too! Do you accept this rose?", choiceA: "Yes", choiceB: "No", nextQuestionA:16, nextQuestionB:0, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 16
            list.append(Question(questionText: "Congrats! You made it to the final 3! You are going to the Fantasy Suites. But the bachelor will only go with those who are pure of heart and are ready for marriage. Time for your one on one with him! The bachelor is obsessed with Mexican culture (maybe a little too much), but it order for his marriage to be successful he needs to know if you like avocados?", choiceA: "Yes", choiceB: "No", nextQuestionA:17, nextQuestionB:20, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 17
            list.append(Question(questionText: "The Bachelor is thrilled you love avocados and deems you ready for the fantasy suite. Would you like to join him?", choiceA: "Yes", choiceB: "No", nextQuestionA:18, nextQuestionB:19, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 18
            list.append(Question(questionText: "You had an amazing time with the bachelor last night! And Congrats he has chosen you to be in the final two. Do you accpet this rose? ", choiceA: "Yes", choiceB: "No", nextQuestionA:21, nextQuestionB:0, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 19
            list.append(Question(questionText: "The bachelor is quite sad that you don’t want to spend the night with him. He thinks it is important before marriage that you two have a sleepover, so therefore he thinks you don’t want to marry him and he sending you home.", choiceA: "Restart", choiceB: "Exit", nextQuestionA:0, nextQuestionB:0, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 20
            list.append(Question(questionText: "The Bachelor is quite surprised that someone of your grace and beauty could not like avocados, even though you said you were allergic. Unfortunately, since the bachelor eats an avocado a day he is sending you home because you two are no longer a match.", choiceA: "Restart", choiceB: "Exit", nextQuestionA:0, nextQuestionB:0, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 21
            list.append(Question(questionText: "Congrats! You and Sarah H.are the final two battling for the bachelor's heart. You are currently awaiting the bachelor's arrival. He walks up and he says before he makes this final decision that will change the rest of his life, he has one last question for you. Are you a cat person or dog person?", choiceA: "Cat", choiceB: "Dog", nextQuestionA:22, nextQuestionB:23, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 22
            list.append(Question(questionText: "The Bachelor drops his head in sadness. He is allergic to cats and he only thinks marriages work out if people like the same animals. He is sending you home. Would you like to slap the bachelor?", choiceA: "Yes", choiceB: "No", nextQuestionA:26, nextQuestionB:27, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 23
            list.append(Question(questionText: "The bachelor smiles, he is super excited for you to join him and his 32 dogs in his condo. He holds your hand as he gets down on one knee and ask, “Will you marry me?”", choiceA: "Yes", choiceB: "No", nextQuestionA:24, nextQuestionB:25, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 24
            list.append(Question(questionText: "Congrats! You won the bachelor!", choiceA: "Restart", choiceB: "Exit", nextQuestionA:0, nextQuestionB:0, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 25
            list.append(Question(questionText: "Chad is quite shocked at the fact you don’t want to spend the rest of your life at 22 with him and his 32 dogs. You tell him that he needs to get his life in order before he marries anyone and will not stand for it. Congrats, the producers loved you and you will be the next bachelorette!", choiceA: "Restart", choiceB: "Exit", nextQuestionA:0, nextQuestionB:0, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question26
            list.append(Question(questionText: "You are now famous and become a meme. Also you were chosen as the bachelorette!", choiceA: "Restart", choiceB: "Exit", nextQuestionA:0, nextQuestionB:0, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            //Question 27
            list.append(Question(questionText: "You were made a meme for crying hysterically on national tv, but you were not chosen to be the bachelorette, the producers thought you were too boring. ", choiceA: "Restart", choiceB: "Exit", nextQuestionA:0, nextQuestionB:0, rosePage: "Yes", rose1: "Yes", rose2: "Yes"))
            
    }
}
