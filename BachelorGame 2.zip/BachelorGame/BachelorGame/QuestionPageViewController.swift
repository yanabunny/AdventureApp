//
//  QuestionPageViewController.swift
//  BachelorGame
//
//  Created by Teriyana Cohens on 5/6/19.
//  Copyright © 2019 Teriyana Cohens. All rights reserved.
//

import UIKit

class QuestionPageViewController: UIViewController {
    let allQuestions = QuestionBank()
    
    //@IBOutlet weak var choice1: UIButton!
    
    @IBOutlet weak var Choice2: UIButton!
    @IBOutlet weak var Choice1: UIButton!
    @IBOutlet weak var questionLabel: UILabel!
    //@IBOutlet weak var choice2: UIButton!
    var questionNumber : Int = 0
    var moveOn : String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        //choice1.tag = 0
        //choice2.tag = 1
        // Do any additional setup after loading the view.
         questionLabel.adjustsFontSizeToFitWidth = true
       // Choice1.setTitle.adjustsFontSizeToFitWidth = true
       // Choice2.setTitle.adjustsFontSizeToFitWidth = true
        
         updateQuestion()
    }

    @IBAction func choiceMade(_ sender: UIButton) {
        if sender.tag == 0{
            questionNumber = allQuestions.list[questionNumber].nextQuestion1
            moveOn = allQuestions.list[questionNumber].roseGiven1
            //questionNumber+=1
            
            updateQuestion()
        }
        else{
            questionNumber = allQuestions.list[questionNumber].nextQuestion2
            moveOn = allQuestions.list[questionNumber].roseGiven2
            //if(allQuestions.list[questionNumber].roseNext == "Yes"){
                //if(moveOn == "Yes"){
                  //  performSegue(withIdentifier: "toRose", sender: self)
                //}
            //}
        }
    }
    func updateQuestion(){
        
    if questionNumber <= allQuestions.list.count-1{
    questionLabel.text = allQuestions.list[questionNumber].question
    Choice1.setTitle(allQuestions.list[questionNumber].choice1, for: UIControlState.normal)
    Choice2.setTitle(allQuestions.list[questionNumber].choice2, for: UIControlState.normal)
       
    }
        //if(allQuestions.list[questionNumber].roseNext == "Yes"){
            //if(moveOn == "Yes"){
                //performSegue(withIdentifier: "toRose", sender: self)
            //}
       //}
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
