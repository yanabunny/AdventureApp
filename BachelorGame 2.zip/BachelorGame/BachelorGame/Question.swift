//
//  Question.swift
//  BachelorGame
//
//  Created by Teriyana Cohens on 5/6/19.
//  Copyright © 2019 Teriyana Cohens. All rights reserved.
//

import Foundation
class Question {
    
    let question: String
    let choice1: String
    let choice2: String
    let nextQuestion1: Int
    let nextQuestion2: Int
    let roseNext: String
    let roseGiven1: String
    let roseGiven2: String
   
    init(questionText: String, choiceA:String, choiceB:String, nextQuestionA:Int, nextQuestionB:Int, rosePage:String, rose1:String, rose2:String){
        
        question = questionText
        choice1 = choiceA
        choice2 = choiceB
        nextQuestion1 = nextQuestionA
        nextQuestion2 = nextQuestionB
        roseNext = rosePage
        roseGiven1 = rose1
        roseGiven2 = rose2
        
    
        
    }
}
